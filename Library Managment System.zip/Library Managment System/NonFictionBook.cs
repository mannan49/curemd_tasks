using System;

public class NonFictionBook : Book
{
    public string Subject { get; set; }

    public NonFictionBook(string title, string author, int bookId, string subject)
        : base(title, author, bookId)
    {
        Subject = subject;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Non-Fiction Book - ID: {BookId}, Title: {Title}, Author: {Author}, Subject: {Subject}");
    }
}
