using System;

public class Librarian : Person
{
    public int EmployeeId { get; set; }

    public Librarian(string name, int age, int personId, int employeeId)
        : base(name, age, personId)
    {
        EmployeeId = employeeId;
    }

    public void IssueBook(Book book, Person user)
    {
        Console.WriteLine($"Book '{book.Title}' issued to {user.Name}.");
    }

    public void ReturnBook(Book book, Person user)
    {
        Console.WriteLine($"Book '{book.Title}' returned by {user.Name}.");
    }
}
