﻿using System;

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
    public int PersonId { get; set; }

    public Person(string name, int age, int personId)
    {
        Name = name;
        Age = age;
        PersonId = personId;
    }
}
