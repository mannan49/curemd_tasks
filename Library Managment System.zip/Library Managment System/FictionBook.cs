using System;

public class FictionBook : Book
{
    public string Genre { get; set; }

    public FictionBook(string title, string author, int bookId, string genre)
        : base(title, author, bookId)
    {
        Genre = genre;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Fiction Book - ID: {BookId}, Title: {Title}, Author: {Author}, Genre: {Genre}");
    }
}
