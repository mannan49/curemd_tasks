﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Create a librarian instance
        Librarian librarian = new Librarian("Manan Nasir", 30, 1, 1001);

        // Create a library instance with the librarian
        Library library = new Library("Allama Iqbal Library", 1, librarian);

        // Create some book instances
        Book book1 = new FictionBook("Raja Gidh", "Bano Qudsiya", 1, "Classic");
        Book book2 = new NonFictionBook("Shahab Nama", "Qudrat Ullah Shahab", 2, "AutoBiography");
        Book book3 = new NonFictionBook("Zero Point", "Javed Chaudhary", 3, "Politics");
        Book book4 = new FictionBook("Shaheen", "Naseem Hijazi", 4, "Fantsy");


        // Adding books to the library
        library.AddBook(book1);
        library.AddBook(book2);
        library.AddBook(book3);
        library.AddBook(book4);

        // Viewing books in the library
        library.ViewBooks();

        // Searching for a book
        library.SearchBook("Shahab Nama");

        // Issuing a book
        Person user = new Person("Zain Ali", 25, 201);
        library.IssueBook(book3, user);

        // Listing issued books
        library.ListIssuedBooks();

        // Returning a book
        library.ReturnBook(book1, user);

        // Viewing books again
        library.ViewBooks();
    }
}
