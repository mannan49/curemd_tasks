﻿using System;

namespace LibraryManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create instances of Book
            Book book1 = new Book("Raja Gidh", "Bano Qudsiya", 1);
            Book book2 = new Book("Shahab Nama", "Qudrat Ullah Shahab", 2);
            Book book3 = new Book("Zero Point", "Javed Chaudhary", 3);

            // Create an instance of Library
            Library myLibrary = new Library("Allama Iqbal Library", 101);

            // Add books to the library
            myLibrary.AddBook(book1);
            myLibrary.AddBook(book2);
            myLibrary.AddBook(book3);

            // View books in the library
            myLibrary.ViewBooks();

            // Remove a book from the library
            myLibrary.RemoveBook(2);

            // View books again to see the updated list
            myLibrary.ViewBooks();
        }
    }
}
