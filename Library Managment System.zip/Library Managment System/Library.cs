﻿using System;
using System.Collections.Generic;

public class Library
{
    public string LibraryName { get; set; }
    public int LibraryId { get; set; }
    private List<Book> books;
    private Librarian librarian;
    private List<Book> issuedBooks;

    public Library(string libraryName, int libraryId, Librarian librarian)
    {
        LibraryName = libraryName;
        LibraryId = libraryId;
        books = new List<Book>();
        issuedBooks = new List<Book>();
        this.librarian = librarian;
    }

    public void AddBook(Book book)
    {
        books.Add(book);
        Console.WriteLine($"Book '{book.Title}' added to the library.");
    }

    public void RemoveBook(int bookId)
    {
        Book bookToRemove = books.Find(b => b.BookId == bookId);
        if (bookToRemove != null)
        {
            books.Remove(bookToRemove);
            Console.WriteLine($"Book '{bookToRemove.Title}' removed from the library.");
        }
        else
        {
            Console.WriteLine("Book not found.");
        }
    }

    public void ViewBooks()
    {
        if (books.Count == 0)
        {
            Console.WriteLine("No books in the library.");
        }
        else
        {
            Console.WriteLine("Books in the library:");
            foreach (var book in books)
            {
                book.DisplayInfo();
            }
        }
    }

    public void SearchBook(string title)
    {
        Book foundBook = books.Find(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        if (foundBook != null)
        {
            Console.WriteLine("Book found:");
            foundBook.DisplayInfo();
        }
        else
        {
            Console.WriteLine("Book not found.");
        }
    }

    public void IssueBook(Book book, Person user)
    {
        if (books.Contains(book))
        {
            issuedBooks.Add(book);
            books.Remove(book);
            librarian.IssueBook(book, user);
        }
        else
        {
            Console.WriteLine("Book is not available for issuing.");
        }
    }

    public void ReturnBook(Book book, Person user)
    {
        if (issuedBooks.Contains(book))
        {
            issuedBooks.Remove(book);
            books.Add(book);
            librarian.ReturnBook(book, user);
        }
        else
        {
            Console.WriteLine("This book was not issued.");
        }
    }

    public void ListIssuedBooks()
    {
        if (issuedBooks.Count == 0)
        {
            Console.WriteLine("No books have been issued.");
        }
        else
        {
            Console.WriteLine("Issued books:");
            foreach (var book in issuedBooks)
            {
                book.DisplayInfo();
            }
        }
    }
}
