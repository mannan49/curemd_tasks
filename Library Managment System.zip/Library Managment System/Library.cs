﻿using System;
using System.Collections.Generic;

namespace LibraryManagementSystem
{
    // Library Class
    public class Library
    {
        // Attributes
        public string LibraryName { get; set; }
        public int LibraryID { get; set; }
        private List<Book> books;

        // Constructor
        public Library(string libraryName, int libraryID)
        {
            LibraryName = libraryName;
            LibraryID = libraryID;
            books = new List<Book>();
        }

        // Methods
        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine($"Book {book.Title} added to the library.");
        }

        public void RemoveBook(int bookID)
        {
            Book bookToRemove = books.Find(b => b.BookID == bookID);
            if (bookToRemove != null)
            {
                books.Remove(bookToRemove);
                Console.WriteLine($"Book {bookToRemove.Title} removed from the library.");
            }
            else
            {
                Console.WriteLine("Book not found.");
            }
        }

        public void ViewBooks()
        {
            Console.WriteLine("Books in the library:");
            foreach (Book book in books)
            {
                book.DisplayInfo();
            }
        }
    }
}
