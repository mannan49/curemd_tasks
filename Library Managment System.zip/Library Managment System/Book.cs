﻿using System;

public abstract class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public int BookId { get; set; }

    protected Book(string title, string author, int bookId)
    {
        Title = title;
        Author = author;
        BookId = bookId;
    }

    public abstract void DisplayInfo();
}
