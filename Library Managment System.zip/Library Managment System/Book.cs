﻿using System;

namespace LibraryManagementSystem
{
    // Book Class
    public class Book
    {
        // Attributes
        public string Title { get; set; }
        public string Author { get; set; }
        public int BookID { get; set; }

        // Constructor
        public Book(string title, string author, int bookID)
        {
            Title = title;
            Author = author;
            BookID = bookID;
        }

        // Methods
        public void DisplayInfo()
        {
            Console.WriteLine($"Book ID: {BookID}, Title: {Title}, Author: {Author}");
        }
    }
}
